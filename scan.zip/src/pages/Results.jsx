import React from "react";
import "../styles/Results.scss";

function Results() {
  return (
    <div className="results-container">
      <div className="top-container">
        <div className="top-text">
          <h1 className="top-h1">
            Ищем. Скоро
            <br /> будут результаты
          </h1>
          <p className="top-p">
            Поиск может занять некоторое время,
            <br /> просим сохранять терпение.
          </p>
        </div>
        <div className="top-img">
          <img src="/assets/results/top-img.png" alt="Девушка с мишенью" />
        </div>
      </div>
    </div>
  );
}

export default Results;
