import React from "react";
import "../styles/Header.scss";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";

function Header() {
  const { userInfo, loadingUser, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <header className="header">
      <div className="logo">
        <img src="/assets/header/header-logo.png" alt="Логотип СКАН" />
      </div>

      <nav className="navigation">
        <Link to="/">Главная</Link>
        <Link to="#">Тарифы</Link>
        <Link to="#">FAQ</Link>
      </nav>

      {loadingUser ? (
        <div className="auth-actions">
          <div className="balance-panel">
            <div className="loader-box">
              <div className="loader" />
            </div>
          </div>
        </div>
      ) : userInfo ? (
        <div className="auth-actions">
          <div className="balance-panel">
            <div className="limits-box">
              <div className="label">
                Использовано компаний{" "}
                <span className="black">
                  {userInfo.eventFiltersInfo.usedCompanyCount ?? 0}
                </span>
              </div>
              <div className="label">
                Лимит по компаниям{" "}
                <span className="green">
                  {userInfo.eventFiltersInfo.companyLimit ?? 0}
                </span>
              </div>
            </div>
          </div>

          <div className="user-info">
            <div className="user-name">
              <p>Алексей А.</p>
              <span onClick={handleLogout}>Выйти</span>
            </div>
            <img
              className="avatar"
              src="/assets/header/avatar.jpg"
              alt="Аватар"
              onClick={handleLogout}
            />
          </div>
        </div>
      ) : (
        <div className="auth-actions">
          {/* eslint-disable-next-line */}
          <a className="auth-link" href="#">
            Зарегистрироваться
          </a>
          <div className="auth-divider"></div>
          <button className="auth-button" onClick={() => navigate("/login")}>
            Войти
          </button>
        </div>
      )}
    </header>
  );
}

export default Header;
